#!/bin/bash
node server4.mjs
